#!/bin/bash

while true; do
  node server.js
  sleep 1
done